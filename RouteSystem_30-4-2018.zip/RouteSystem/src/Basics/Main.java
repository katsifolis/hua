/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Basics;

import FileManager.FileManager;
import Mapping.Hash;
import Database.Database;
import java.io.*;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String args[]) {

        String filePath = "routes.txt";
        FileManager fm = new FileManager();
        HashMap<String, Route> RouteHash = new HashMap<>();
        ArrayList<String> RouteId = new ArrayList<>();

        String line;
        try {

            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            int counter = 0;

            while ((line = reader.readLine()) != null) {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Route tmp = fm.getRouteFromString(line);
                RouteId.add(tmp.getRoute_id());
                RouteHash.put(tmp.getRoute_id(), tmp);
                
                counter++;
            }
            reader.close();
            Hash.setAllRoutes(RouteHash);
            Hash.setAllRouteId(RouteId);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        } 

        String filePath1 = "trips.txt";
        HashMap<String, Trip> TripHash = new HashMap<>();
        ArrayList<String> TripId = new ArrayList<>();
        
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(filePath1));
            int counter = 0;
            while ((line = reader1.readLine()) != null) {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Trip tmp = fm.getTripFromString(line);
                TripHash.put(tmp.getTrip_id(), tmp);
                TripId.add(tmp.getTrip_id());
                
                
                counter++;
            }

            reader1.close();
            Hash.setAllTrips(TripHash);
            Hash.setAllTripId(TripId);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        String filename2 = "stops.txt";
        HashMap<String, Stop> StopHash = new HashMap<>();
        ArrayList<String> StopId = new ArrayList<>();
        try {
            BufferedReader reader2 = new BufferedReader(new FileReader(filename2));
            int counter = 0;
            while ((line = reader2.readLine()) != null) {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Stop tmp = fm.getStopFromString(line);
                StopHash.put(tmp.getStop_id(), tmp);
                StopId.add(tmp.getStop_id());
                

                counter++;
            }
            reader2.close();
            Hash.setAllStops(StopHash);
            Hash.setAllStopId(StopId);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        

        //Read Stop_Times
        String filename3 = "stop_times.txt";
        HashMap<String, StopTime> StopTimeHash = new HashMap<>();
        try {
            BufferedReader reader3 = new BufferedReader(new FileReader(filename3));
            int counter = 0;
            while ((line = reader3.readLine()) != null) {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                StopTime tmp = fm.getStopTimeFromString(line);
                StopTimeHash.put(tmp.getStop_id(), tmp);
                Trip tr = Hash.allTrips.get(tmp.getTrip_id());
                tr.addStops(Hash.allStops.get(tmp.getStop_id()));

                counter++;
            }
            reader3.close();
            Hash.setAllStopTime(StopTimeHash);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print(Hash.allRouteId.size());
        Database.getDBConnection();
        
        // change to 0 after testing
        int c = 288;
        int c1 = 0;
        int c2 = 0;
        try {
            while(c < Hash.allRouteId.size()) {
                String route_id = Hash.allRouteId.get(c);
                Database.RouteInsertIntoTable(route_id);
                c = c + 1;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        
        try {
            while(Hash.allStopId.size() > c1) {
                String stop_id = Hash.allStopId.get(c1);
                Database.StopInsertIntoTable(stop_id);
                c1 = c1 + 1;
            }
        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        try {
            while(c2 < Hash.allTripId.size()) {
                String trip_id = Hash.allTripId.get(c2);
                Database.TripInsertIntoTable(trip_id);
                c2 = c2 + 1;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        

    }
}
