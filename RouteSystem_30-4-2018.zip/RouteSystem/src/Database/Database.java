/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Mapping.Hash;
import Basics.*;
import java.io.*;
import java.util.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.text.*;

public class Database {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";

    private static final String DB_CONNECTION = "jdbc:oracle:thin:@oracle12c.hua.gr:1521:orcl";

    private static final String DB_USER = "IT21633";

    private static final String DB_PASSWORD = "IT21633";

    public static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }

        return dbConnection;

    }

    public static void RouteInsertIntoTable(String route_id) throws SQLException {

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;

        String insertRouteTableSQL = "INSERT INTO ROUTE"
                + "(ROUTE_ID, ROUTE_SHORT_NAME, ROUTE_LONG_NAME, ROUTE_DESC, ROUTE_TYPE, ROUTE_COLOR, ROUTE_TEXT_COLOR) VALUES"
                + "(?,?,?,?,?,?,?)";

        Route r = Hash.allRoutes.get(route_id);

        try {

            dbConnection = Database.getDBConnection();
            preparedStatement = dbConnection.prepareStatement(insertRouteTableSQL);

            preparedStatement.setString(1, r.getRoute_id());
            preparedStatement.setString(2, r.getRoute_short_name());
            preparedStatement.setString(3, r.getRoute_long_name());
            preparedStatement.setString(4, r.getRoute_desc());
            preparedStatement.setInt(5, r.getRoute_type());
            preparedStatement.setString(6, r.getRoute_color());
            preparedStatement.setString(7, r.getRoute_text_color());

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }

        }

    }

    public static void StopInsertIntoTable(String stop_id) throws SQLException {

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;

        String insertStopTableSQL = "INSERT INTO STOP"
                + "(STOP_ID, STOP_CODE, STOP_NAME, STOP_DESC, STOP_LAT, STOP_LON) VALUES"
                + "(?,?,?,?,?,?)";

        Stop s = Hash.allStops.get(stop_id);

        try {

            dbConnection = Database.getDBConnection();
            preparedStatement = dbConnection.prepareStatement(insertStopTableSQL);

            preparedStatement.setString(1, s.getStop_id());
            preparedStatement.setString(2, s.getStop_code());
            preparedStatement.setString(3, s.getStop_name());
            preparedStatement.setString(4, s.getStop_desc());
            preparedStatement.setString(5, s.getStop_lat());
            preparedStatement.setString(6, s.getStop_lon());

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }

        }
    }


    public static void TripInsertIntoTable(String trip_id) throws SQLException {

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;

        String insertStopTableSQL = "INSERT INTO TRIP"
                + "(ROUTE_ID, SERVICE_ID, TRIP_ID, TRIP_HEADSIGN, BLOCK_ID, SHAPE_ID) VALUES"
                + "(?,?,?,?,?)";

        Trip t = Hash.allTrips.get(trip_id);

        try {

            dbConnection = Database.getDBConnection();
            preparedStatement = dbConnection.prepareStatement(insertStopTableSQL);

            preparedStatement.setString(1, t.getRoute_id());
            preparedStatement.setString(2, t.getService_id());
            preparedStatement.setString(3, t.getTrip_id());
            preparedStatement.setString(4, t.getTrip_headsign());
            preparedStatement.setString(5, t.getBlock_id());
            preparedStatement.setString(6, t.getShape_id());

            // execute insert SQL stetement
            preparedStatement.executeUpdate();

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }

        }
    }
}