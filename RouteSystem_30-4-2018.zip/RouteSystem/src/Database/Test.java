/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import Database.Database;
import Mapping.Hash;
import Basics.*;



public class Test {

   
    

    public static void main(String[] argv) {

        int c = 1;
        try {
            while(c <= Hash.allRouteId.size()) {
                String route_id = Hash.allRouteId.get(c);
                Database.RouteInsertIntoTable(route_id);
                c++;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }

    }

//    private static void insertRecordIntoTable() throws SQLException {
//
//        Connection dbConnection = null;
//        PreparedStatement preparedStatement = null;
//
//        String insertTableSQL = "INSERT INTO ROUTES"
//                + "(ROUTE_ID, ROUTE_SHORT_NAME, ROUTE_LONG_NAME, ROUTE_DESC, ROUTE_TYPE, ROUTE_COLOR, ROUTE_TEXT_COLOR) VALUES"
//                + "(?,?,?,?,?,?,?)";
//
//        try {
//            dbConnection = Database.getDBConnection();
//            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
//
//            
//            preparedStatement.setInt(1, 11);
//            preparedStatement.setString(2, "mkyong");
//            preparedStatement.setString(3, "system");
//            preparedStatement.setTimestamp(4, getCurrentTimeStamp());
//
//            // execute insert SQL stetement
//            preparedStatement.executeUpdate();
//
//            System.out.println("Record is inserted into DBUSER table!");
//
//        } catch (SQLException e) {
//
//            System.out.println(e.getMessage());
//
//        } finally {
//
//            if (preparedStatement != null) {
//                preparedStatement.close();
//            }
//
//            if (dbConnection != null) {
//                dbConnection.close();
//            }
//
//        }
//
//    }
//
//    
//
//    private static java.sql.Timestamp getCurrentTimeStamp() {
//
//        java.util.Date today = new java.util.Date();
//        return new java.sql.Timestamp(today.getTime());
//
//    }

}
