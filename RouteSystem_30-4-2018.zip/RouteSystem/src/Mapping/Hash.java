/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mapping;

import Basics.Route;
import Basics.Stop;
import Basics.Trip;
import Basics.StopTime;

import java.util.HashMap;
import java.util.ArrayList;

public class Hash {
    
    public static HashMap<String, Route> allRoutes;
    
    public static HashMap<String, Trip> allTrips;
    
    public static HashMap<String, Stop> allStops;
    
    public static HashMap<String, StopTime> allStopTime;
    
    public static ArrayList<String> allRouteId;
    
    public static ArrayList<String> allTripId;

    public static ArrayList<String> allStopId;

    public static ArrayList<String> allStopTimeId;

    public static void setAllRouteId(ArrayList<String> allRouteId) {
        Hash.allRouteId = allRouteId;
    }

    public static void setAllTripId(ArrayList<String> allTripId) {
        Hash.allTripId = allTripId;
    }

    public static void setAllStopId(ArrayList<String> allStopId) {
        Hash.allStopId = allStopId;
    }

    public static void setAllStopTimeId(ArrayList<String> allStopTimeId) {
        Hash.allStopTimeId = allStopTimeId;
    }


    
    
    public static void setAllStopTime(HashMap<String, StopTime> allStopTime) {
        Hash.allStopTime = allStopTime;
    }

    public static HashMap<String, StopTime> getAllStopTime() {
        return allStopTime;
    }

    public static HashMap<String, Route> getAllRoutes() {
        return allRoutes;
    }

    public static void setAllRoutes(HashMap<String, Route> allRoutes) {
        Hash.allRoutes = allRoutes;
    }

    public static HashMap<String, Trip> getAllTrips() {
        return allTrips;
    }

    public static void setAllTrips(HashMap<String, Trip> allTrips) {
        Hash.allTrips = allTrips;
    }

    public static HashMap<String, Stop> getAllStops() {
        return allStops;
    }

    public static void setAllStops(HashMap<String, Stop> allStops) {
        Hash.allStops = allStops;
    }   

    public static ArrayList<String> getAllRouteId() {
        return allRouteId;
    }

    public static ArrayList<String> getAllTripId() {
        return allTripId;
    }

    public static ArrayList<String> getAllStopId() {
        return allStopId;
    }

    public static ArrayList<String> getAllStopTimeId() {
        return allStopTimeId;
    }
    
    
    
}

