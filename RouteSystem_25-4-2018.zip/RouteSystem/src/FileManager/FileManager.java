/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FileManager;

import Basics.Route;
import Basics.Trip;
import Basics.Stop;
import Basics.StopTime;
import Basics.Database;
import Mapping.Hash;
import java.lang.Iterable;
import java.util.HashMap;



public class FileManager {


    public Route getRouteFromString(String row) {
        String[] rowTokens = row.split(",");
        String route_id = rowTokens[0];
        String route_short_name = rowTokens[1];
        String route_long_name = rowTokens[2];
        String route_desc = rowTokens[3];
        Integer route_type = Integer.parseInt(rowTokens[4]);
        String route_color = rowTokens[5];
        String route_text_color = rowTokens[6];
            
        Route ro = new Route(route_id, route_short_name, route_long_name,route_desc, route_type, route_color, route_text_color);
        return ro;
    }
    
    public Trip getTripFromString(String row) {
        String[] rowTokens = row.split(",", 6);
        String route_id = rowTokens[0];
        String service_id = rowTokens[1];
        String trip_id = rowTokens[2]; 
        String trip_headsign = rowTokens[3];
        //String trip_direction_id = rowTokens[4];
        String trip_block_id = rowTokens[4];
        String trip_shape_id = rowTokens[5];
        
        
        Route curRoute = Hash.allRoutes.get(route_id);
        Trip tr = new Trip(curRoute, service_id, trip_id, trip_headsign, trip_block_id, trip_shape_id);
        
        return tr;
        
    }
    
    public Stop getStopFromString(String row) {
        String[] rowTokens = row.split(",", 6);
        String stop_id = rowTokens[0];
        String stop_code = rowTokens[1];
        String stop_name = rowTokens[2];
        String stop_desc = rowTokens[3];
        String stop_lat = rowTokens[4];
        String stop_lon = rowTokens[5];
        
        
        Stop st = new Stop(stop_id, stop_code, stop_name, stop_desc, stop_lat, stop_lon);
        return st;
    }

    public StopTime getStopTimeFromString(String row) {
        String[] rowTokens = row.split(",");
        String trip_id = rowTokens[0];
        String stop_id = rowTokens[1];
        String stop_sequence = rowTokens[2];
        String pickup_type = rowTokens[3];
        String drop_off_type = rowTokens[4];
        
        StopTime stt = new StopTime(trip_id, stop_id, stop_sequence, pickup_type, drop_off_type);
        return stt;
    }
    
//    public String getTrip_id(String row) {
//            String[] rowToken = row.split(",", 1);
//            String trip_id = rowToken[0];
//            return trip_id;
//    }

    
}
