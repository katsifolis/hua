/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Basics;

import FileManager.FileManager;
import Mapping.Hash;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Database {
    
    
    
    public static void main(String args[]) {

        String filePath = "routes.txt";
        FileManager fm = new FileManager();
        HashMap<String, Route> RouteHash = new HashMap<>();
        
        String line;
        try {

            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            int counter = 0;

            while ((line = reader.readLine()) != null)
            {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Route tmp = fm.getRouteFromString(line);
                RouteHash.put(tmp.getRoute_id(), tmp);

                counter++;
            }
            reader.close();
            Hash.setAllRoutes(RouteHash);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        
 
        String filePath1 = "trips.txt";
        HashMap<String, Trip> TripHash = new HashMap<>();
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(filePath1));
            int counter = 0;
            while ((line = reader1.readLine()) != null)
            {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Trip tmp = fm.getTripFromString(line);
                TripHash.put(tmp.getRoute().getRoute_id(), tmp);
                    


                counter++;
            }
            
            reader1.close();
            Hash.setAllTrips(TripHash);
            

            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }    
//            System.out.print(TripHash.get("4-20").getRoute().getRoute_text_color());
            
                //Read Stops
            String filename2 = "stops.txt";
            HashMap<String, Stop> StopHash = new HashMap<>();
            try {
                BufferedReader reader2 = new BufferedReader(new FileReader(filename2));
                int counter = 0;
                while ((line = reader2.readLine()) != null)
                {
                // Skip the first line
                if (counter == 0) {
                    counter++;
                    continue;
                }
                Stop tmp = fm.getStopFromString(line);
                
                StopHash.put(tmp.getStop_id(), tmp);

                counter++;
            }
                reader2.close();
                Hash.setAllStops(StopHash);
//                System.out.print(StopHash.get("010010").getStop_desc());
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            String filename3 = "stop_times.txt";
            HashMap<String, StopTime> StopTimeHash = new HashMap<>();
            try {
                BufferedReader reader3 = new BufferedReader(new FileReader(filename2));
                int counter = 0;
                while ((line = reader3.readLine()) != null)
                {
                    // Skip the first line
                    if (counter == 0) {
                        counter++;
                        continue;
                    }
                    StopTime tmp = fm.getStopTimeFromString(line);
                    Stop st = StopHash.get(tmp.getStop_id());
                    Trip tr = TripHash.get(tmp.getTrip_id());
                    
                    if (tmp.getStop_id() == st.getStop_id()) {
                        if (tmp.getTrip_id() == tr.getTrip_id())
                            StopTimeHash.put(tmp.getStop_id(), tmp);
                    }
                    

                    counter++;
            }
                reader3.close();
                System.out.print(StopTimeHash.get("400045").getTrip_id());
                
//                System.out.print(StopHash.get("010010").getStop_desc());
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
            }
            
 
    }
}
