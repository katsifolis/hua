/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Basics;

//Κλάση ΔΡΟΜΟΛΟΓΙΟΥ

import java.util.logging.Logger;


public class Trip {
    
    private Route route;
// Ready to delete
    private String route_id;
    //   
    private String service_id;

    private String trip_id;
    
    private String trip_headsign;
    
    private String block_id;
    
    private String shape_id;
    
    private Stop stop;
    
    // Constructor

    public Trip(Route route, String service_id, String trip_id, String trip_headsign, String block_id, String shape_id, Stop stop) {
        
        this.route = route;
        this.service_id = service_id;
        this.trip_id = trip_id;
        this.trip_headsign = trip_headsign;
        this.block_id = block_id;
        this.shape_id = shape_id;
        this.stop = stop;
        
    }
    
    // Getters
    
    public Stop getStop() {
        return stop;
    }

    public String getBlock_id() {
        return block_id;
    }

    public String getRoute_id() {
        return route_id;
    }
    
    public Route getRoute() {
        return route;
    }

    public String getTrip_id() {
        return trip_id;
    }
    
    public String getShape_id() {
        return shape_id;
    }

    public String getService_id() {
        return service_id;
    }

    public String getTrip_headsign() {
        return trip_headsign;
    }

    // Setters
        
     public void setStop(Stop stop) {
        this.stop = stop;
    }

    public void setRoute_id(String route_id) {
        this.route_id = route_id;
    }
    public void setBlock_id(String block_id) {
        this.block_id = block_id;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    
    
    public void setShape_id(String shape_id) {
        this.shape_id = shape_id;
    }
    

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public void setTrip_headsign(String trip_headsign) {
        this.trip_headsign = trip_headsign;
    }

    public void setTrip_id(String trip_id) {
        this.trip_id = trip_id;
    }

    
    
    
    
    
}
